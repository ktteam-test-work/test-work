<?php

namespace App\Controller;

use App\Entity\Task;
use App\Form\TaskType;
use App\Repository\TaskRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Elasticsearch\ClientBuilder;
use Elasticsearch\Client;
use App\Service\ElasticsearchService;
use App\Form\SearchFormType;
use App\Entity\User;
use Knp\Component\Pager\PaginatorInterface;
use App\Repository\UserRepository;
use ReflectionClass;
use ReflectionException;
use ReflectionProperty;

class TasksController extends AbstractController//AbstractFOSRestController
{

    /** @var TaskRepository $taskRepository */
    private $taskRepository;
    /**
     * @var PaginatorInterface
     */
    private $paginator;
    /**
     * @var UserRepository
     */
    private $userRepository;

    public function __construct(
        TaskRepository $taskRepository,
        PaginatorInterface $paginator,
        UserRepository $userRepository
    )
    {
        $this->taskRepository = $taskRepository;
        $this->paginator = $paginator;
        $this->userRepository = $userRepository;
    }

//    /**
//     * @Route("/tasks", name="tasks")
//     */
//    public function index()
//    {
//        $tasks = $this->taskRepository->findAll();
//
//        return new JsonResponse($tasks);
//
//    }



    /**
     * @Route("/", name="index")
     */
    public function index(ElasticsearchService $elasticSearchService, Request $request)
    {
        $searchForm = $this->createForm(SearchFormType::class);
        $searchForm->handleRequest($request);
        if ($searchForm->isSubmitted() && $searchForm->isValid()) {
            $formData = $searchForm->getData();
            //$searchQuery = $formData['query'] ?? '';
            //$tasks = $elasticSearchService->getList($searchQuery);
            $tasks = $elasticSearchService->getList($formData);
        } else {

//            $taskRepository = $this->getDoctrine()->getRepository(Task::class);
            $tasks = $this->taskRepository->findAll();
//            if (isset($_GET['user']) && $_GET['user'] ) {
//                $tasks = $elasticSearchService->getList($_GET['user']);
//            }
        }

//        foreach ($tasks as &$task)
//        {
//            $user = $task->getUser();
//            if ($user) {
//                $task->user_id = $user->getId();
//            }
//        }

        $pagination = $this->paginator->paginate($tasks, $request->query->getInt('page', 1), 5);

        return $this->render('tasks/index.html.twig', [
//            'tasks' => $tasks,
            'searchForm' => $searchForm->createView(),
            'pagination' => $pagination
        ]);
    }



    /**
     * @Route("/tasks", name="tasks")
     */
    public function tasks(ElasticsearchService $elasticSearchService, Request $request)
    {
//        $searchForm = $this->createForm(SearchFormType::class);
//        $searchForm->handleRequest($request);
//        if ($searchForm->isSubmitted() && $searchForm->isValid()) {
//            $formData = $searchForm->getData();
//            $searchQuery = $formData['query'] ?? '';
//            $users = $elasticSearchService->getList($searchQuery);
//        } else {
//            $userRepository = $this->getDoctrine()->getRepository(User::class);
//            $users = $userRepository->findAll();
//        }
//
//        return $this->render('users/index.html.twig', [
//            'users' => $users,
//            'searchForm' => $searchForm->createView()
//        ]);


        $tasks = $this->taskRepository->findAll();
        $tasksArr = array();

        foreach ($tasks as $task) {

            $taskItem = Task::getArrayForJsonOutput($task);
//            $reflect = new ReflectionClass($task);
//            $props   = $reflect->getProperties();
//            $taskItem = array();
//
//            foreach ($props as $prop) {
//                $nameProperty = $prop->getName();
//                $prop->setAccessible(true);
//                $taskItem[$nameProperty] = $prop->getValue($task);
//            }
//
            $tasksArr[] = $taskItem;
        }

        return new JsonResponse($tasksArr);

//        return $this->render('tasks/index.html.twig', [
//            'tasks' => $tasks,
//        ]);
    }

    /**
     * @Route("/tasks/new", name="new_task_post")
     */
    public function addTask(Request $request)
    {
        $task = new Task();
        $form = $this->createForm(TaskType::class, $task);
        $form->handleRequest($request);

        $fp = fopen('zzz.txt', 'a');
//        fwrite($fp, '$_POST---'.json_encode($_POST)."\n");
        fwrite($fp, 'TASK - $request->request->all()---'.json_encode($request->request->all())."\n");
//        fwrite($fp, '$form->isValid()---'.$form->isValid()."\n");
//        fwrite($fp, '$form->isSubmitted()---'.$form->isSubmitted()."\n");
//        fwrite($fp, 'json_encode($form)---'.json_encode($form)."\n");
        fwrite($fp, '$form->getErrors()---'.$form->getErrors()."\n");
        fclose($fp);

        if ($form->isSubmitted() && $form->isValid()) {

            $fp = fopen('zzz.txt', 'a');
            fwrite($fp, 'IN SUBMIT'."\n");
            fclose($fp);

            $data = $form->getData();

            //.json_encode($data)
//            $fp = fopen('zzz.txt', 'a');
//            fwrite($fp, '$data->getUser()---'.$data->getUser()."\n");
//            fclose($fp);

            $user_id = $data->getUser();
//$fp = fopen('zzz.txt', 'a');
//fwrite($fp, 'STEP-1---'."\n");
//fclose($fp);
            $user = $this->userRepository->find($user_id);
            $task->setUser($user);
            $task->setCreatedAt(new \DateTime());

            $em = $this->getDoctrine()->getManager();
            $em->persist($task);
            $em->flush();

//$fp = fopen('zzz.txt', 'a');
//fwrite($fp, 'STEP-10---'."\n");
//fclose($fp);

            //ДОБАВЛЕНИЕ В ИНДЕКС ELASTICSEARCH
//            $client = ClientBuilder::create()->build();
//            $params = [
//                "index" => "task",
//                "type"  => "task",
//                "id"    => $task->getId(),
//                "body"  => [
//                    "id" => $task->getId(),
//                    "title" => $task->getTitle(),
//                    "body"  => $task->getBody(),
//                    "user"  => $user->getId(),
//                    "created_at" => $task->getCreatedAt()->format('Y-m-d')//date('Y-m-d', strtotime("10 September 2000"))//$createdAt->format('Y-m-d H:i:s')//$date//$task->getCreatedAt()
//                ]
//            ];
//            $response = $client->index($params);
            //END - ДОБАВЛЕНИЕ В ИНДЕКС ELASTICSEARCH

            $headers = [
                'Location' => $this->generateUrl('task_show', ['id' => $task->getId()]),
            ];

            return new JsonResponse(Task::getArrayForJsonOutput($task), JsonResponse::HTTP_CREATED, $headers);

            //return new JsonResponse($response); //$this->redirectToRoute('tasks');
        }
        return $this->render('tasks/new.html.twig', [
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/tasks/{id}", name="task_show")
     */
    public function task(Task $task)
    {
        //$task = ['zzz'=>'aaa', 'xxx'=>'bbb'];
        //$task = (array) $task;
        //$normalizer = new JsonSerializableNormalizer();
        //$task = $normalizer->normalize($task);

        $task = Task::getArrayForJsonOutput($task);
        return new JsonResponse($task);
//        return $this->render('tasks/show.html.twig', [
//            'task' => $task
//        ]);
    }

    /**
     * @Route("/tasks/{id}", name="task_show")
     */
//    public function task(Task $task)
//    {
//        return $this->render('tasks/show.html.twig', [
//            'task' => $task
//        ]);
//    }

    /**
     * @Route("/tasks/{id}/edit", name="task_edit")
     */
    public function edit(Task $task, Request $request)
    {
        //$task->setUser($user);
        $form = $this->createForm(TaskType::class, $task);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            //$task->setUser('duser');
            $em = $this->getDoctrine()->getManager();
            $em->flush();

//            return $this->redirectToRoute('task_show', [
//                'id' => $task->getId()
//            ]);

            $headers = [
                'Location' => $this->generateUrl('task_show', ['id' => $task->getId()]),
            ];

            return new JsonResponse(Task::getArrayForJsonOutput($task), JsonResponse::HTTP_CREATED, $headers);

        }

        return $this->render('tasks/new.html.twig', [
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/tasks/{id}/delete", name="task_delete")
     */
    public function delete(Task $task)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove($task);
        $em->flush();

        //return $this->redirectToRoute('tasks');
//        return new JsonResponse(null, JsonResponse::HTTP_NO_CONTENT);



        $tasks = $this->taskRepository->findAll();
        $tasksArr = array();

        foreach ($tasks as $task) {
            $taskItem = Task::getArrayForJsonOutput($task);
            $tasksArr[] = $taskItem;
        }

        $headers = [
            'Location' => $this->generateUrl('tasks'),
        ];

        return new JsonResponse($tasksArr, JsonResponse::HTTP_OK, $headers);
    }


}
