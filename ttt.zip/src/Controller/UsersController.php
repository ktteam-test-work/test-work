<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\UserType;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Elasticsearch\ClientBuilder;

class UsersController extends AbstractController
{

    /** @var UserRepository $userRepository */
    private $userRepository;
    /**
     * @var PaginatorInterface
     */
    private $paginator;

    public function __construct(
        UserRepository $userRepository,
        PaginatorInterface $paginator
    )
    {
        $this->userRepository = $userRepository;
        $this->paginator = $paginator;
    }

    /**
     * @Route("/users", name="users")
     */
    public function users(Request $request)
    {
        $users = $this->userRepository->findAll();

        $pagination = $this->paginator->paginate($users, $request->query->getInt('page', 1), 5);

        return $this->render('users/index.html.twig', [
            //'users' => $users,
            'pagination' => $pagination,
        ]);
    }

    /**
     * @Route("/users/new", name="new_user_post")
     */
    public function addUser(Request $request)
    {
        $user = new User();
        $form = $this->createForm(UserType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $userData = $request->request->get('user');
            $user->setAlias($userData['alias']);
            $user->setFirstName($userData['firstname']);
            $user->setLastName($userData['lastname']);

            $em = $this->getDoctrine()->getManager();
            $em->persist($user);
            $em->flush();

            //ДОБАВЛЕНИЕ В ИНДЕКС ELASTICSEARCH
//            $client = ClientBuilder::create()->build();
//            $params = [
//                "index" => "user",
//                "type"  => "user",
//                "id"    => $user->getId(),
//                "body"  => [
//                    "id" => $user->getId(),
//                    "alias" => $user->getAlias(),
//                    "firstname"  => $user->getFirstname(),
//                    "lastname"  => $user->getLastname()
//                ]
//            ];
//            $response = $client->index($params);
            //END - ДОБАВЛЕНИЕ В ИНДЕКС ELASTICSEARCH

            $headers = [
                'Location' => $this->generateUrl('user_show', ['id' => $user->getId()]),
            ];

            return new JsonResponse(User::getArrayForJsonOutput($user), JsonResponse::HTTP_CREATED, $headers);

            //return $this->redirectToRoute('users');
        }
        return $this->render('users/new.html.twig', [
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/users/{id}", name="user_show")
     */
    public function user(User $user)
    {
        $user = User::getArrayForJsonOutput($user);
        return new JsonResponse($user);
//        return $this->render('users/show.html.twig', [
//            'user' => $user
//        ]);
    }

    /**
     * @Route("/users/{id}/edit", name="user_edit")
     */
    public function edit(User $user, Request $request)
    {
        $form = $this->createForm(UserType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $userData = $request->request->get('user');
            $user->setAlias($userData['alias']);
            $user->setFirstName($userData['firstname']);
            $user->setLastName($userData['lastname']);
            $em = $this->getDoctrine()->getManager();
            $em->flush();

            $headers = [
                'Location' => $this->generateUrl('user_show', ['id' => $user->getId()]),
            ];

            return new JsonResponse(User::getArrayForJsonOutput($user), JsonResponse::HTTP_CREATED, $headers);

//            return $this->redirectToRoute('user_show', [
//                'id' => $user->getId()
//            ]);
        }

        return $this->render('users/new.html.twig', [
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/users/{id}/delete", name="user_delete")
     */
    public function delete(User $user)
    {
        $em = $this->getDoctrine()->getManager();
        $em->remove($user);
        $em->flush();

        //return $this->redirectToRoute('users');
        return new JsonResponse(null, JsonResponse::HTTP_NO_CONTENT);
    }
}
