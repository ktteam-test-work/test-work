<?php declare(strict_types = 1);

namespace App\Tests\Controller;

use App\Entity\Task;
//use App\Repository\TaskRepository;
//use Doctrine\Persistence\ManagerRegistry;
use App\Entity\User;
use function json_decode;
use function json_encode;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class TaskControllerTest extends WebTestCase
{
    public function testListingAllTasks()
    {
        $client = static::createClient();

        $client->request('GET', '/tasks');
        $response = $client->getResponse();

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertSame('application/json', $response->headers->get('Content-Type'));
        $this->assertJson($response->getContent());
    }

    public function testGettingSingleTask()
    {
        $client = static::createClient();

        $client->request('GET', '/tasks/12');
        $response = $client->getResponse();

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertSame('application/json', $response->headers->get('Content-Type'));
        $task = json_decode($response->getContent());
        $this->assertSame(12, $task->task->id);
    }

    public function testCreatingTask()
    {
        $client = static::createClient();

        $token = $client->getContainer()->get('security.csrf.token_manager')->getToken('task')->getValue();

        $task = ['task' => ['title' => 'test-title', 'body' => 'test-body', 'user' => '3','_token' => $token]];
        //$taskJson = json_encode($task);

        $client->request('POST', '/tasks/new', $task, [], []);
        $response = $client->getResponse();

        $this->assertEquals(201, $response->getStatusCode());
        $this->assertSame('application/json', $response->headers->get('Content-Type'));
        $this->assertTrue($response->headers->has('Location'));
        $this->assertContains('/tasks/21', $response->headers->get('Location'));

        $client->request('GET', $response->headers->get('Location'));
        $response = $client->getResponse();

        $this->assertEquals(200, $response->getStatusCode());
        $this->assertSame('application/json', $response->headers->get('Content-Type'));
        $responseJsonDecoded = json_decode($response->getContent());
        $this->assertEquals($task['task']['title'], $responseJsonDecoded->task->title);
        $this->assertEquals($task['task']['body'], $responseJsonDecoded->task->body);
    }

    public function testUpdatingExistingTask()
    {
        $client = static::createClient();
        $task = new Task();
        $task->setBody('new-test-body');
        $token = $client->getContainer()->get('security.csrf.token_manager')->getToken('task')->getValue();
        $taskJson = ['task' => ['title' => 'test-title', 'body' => $task->getBody(), 'user' => '3','_token' => $token]];
        //$taskJson = json_encode($task);

        //#################$taskRepository = new TaskRepository(ManagerRegistry $registry);

        $client->request('POST', '/tasks/21/edit', $taskJson, [], []);
        $response = $client->getResponse();

        $this->assertEquals(201, $response->getStatusCode());
        $this->assertSame('application/json', $response->headers->get('Content-Type'));

//        $updatedProduct = Task::fromArray(json_decode($response->getContent(), true));

        $updatedTask = json_decode($response->getContent());

//        $fp = fopen('zzz.txt', 'a');
//        fwrite($fp, '$task---'.json_encode($updatedTask->task->id)."\n");
//        fclose($fp);

        $this->assertEquals(21, $updatedTask->task->id);
        $this->assertSame('test-title', $updatedTask->task->title);
        $this->assertSame($task->getBody(), $updatedTask->task->body);
        $this->assertEquals(3, $updatedTask->task->user);
    }

    public function testDeletingTask()
    {
        $client = static::createClient();

        $client->request('DELETE', '/tasks/21/delete');
        $response = $client->getResponse();

        $this->assertEquals(200, $response->getStatusCode());

        $client->request('GET', '/tasks/21');
        $response = $client->getResponse();

        $this->assertEquals(404, $response->getStatusCode());
    }
//
//    public function test_not_found_returns_json_error()
//    {
//        $client = static::createClient();
//
//        $client->request('GET', '/api/spaceships');
//        $response = $client->getResponse();
//
//        $this->assertEquals(404, $response->getStatusCode());
//        $this->assertSame('application/json', $response->headers->get('Content-Type'));
//        $this->assertJsonStringEqualsJsonString(
//            '{"type":"NotFoundHttpException","message":"No route found for \"GET \/api\/spaceships\""}',
//            $response->getContent()
//        );
//    }
}